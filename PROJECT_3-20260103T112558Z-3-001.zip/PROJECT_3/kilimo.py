from flask import Flask, render_template, request
import tensorflow as tf
import pandas as pd
import numpy as np

app = Flask(__name__)

# Load the model
model = tf.keras.models.load_model('mabala.keras', custom_objects={'mse': tf.keras.losses.MeanSquaredError()})

# Continue with your predict_species and routes...

# Function to predict iris species
def predict_crop(model, Nitrogen,Phosphorus,Potassium,temperature,humidity,ph,rainfall):
    try:
        input_data = pd.DataFrame([[float(Nitrogen), float(Phosphorus), float(Potassium), float(temperature),float(humidity),float(ph),float(rainfall)]],
                                  columns=['Nitrogen','Phosphorus','Potassium','temperature','humidity','ph','rainfall'])
        # Ensure proper input shape
        probabilities = model.predict(input_data)
        predicted_class = np.argmax(probabilities, axis=1)
        crop_map = {0: 'rice', 1: 'maize', 2: 'chickpea',3:'kidneybeans',4:'pigeonpeas',5:'mothbeans',6:'mungbean',7:'blackgram',8:'lentil',9:'pomegranate',10:'banana',11:'mango',12:'grapes',13:'watermelon',14:'muskmelon',15:'apple',16:'orange',17:'papaya',18:'coconut',19:'cotton',20:'jute',21:'coffee'}
        predicted_crop = crop_map[predicted_class[0]]
        return predicted_crop
    except Exception as e:
        print(f"Error in prediction: {e}")
        return "Error predicting crops"

@app.route('/')
def prinery():
    return render_template('prinery.html', result='')

@app.route('/predict', methods=['POST'])
def predict():
    Nitrogen = request.form.get('Nitrogen')
    Phosphorus= request.form.get('Phosphorus')
    Potassium = request.form.get('Potassium')
    temperature = request.form.get('temperature')
    humidity=request.form.get('humidity')
    ph=request.form.get('ph')
    rainfall=request.form.get('rainfall')
    

    # Validate input
    if not all([Nitrogen,Phosphorus,Potassium,temperature,humidity,ph,rainfall]):
        return render_template('priney.html', result="Please fill all fields.")

    # Use the loaded model for prediction
    crop = predict_crop(model, Nitrogen,Phosphorus,Potassium,temperature,humidity,ph,rainfall)

    return render_template('prinery.html', result=f"The crop is: {crop}")

if __name__ == "__main__":
    app.run(debug=True, port=5002)
